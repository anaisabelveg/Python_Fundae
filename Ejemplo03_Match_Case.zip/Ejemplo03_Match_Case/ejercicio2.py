'''
    solicitar al usuario un numero del 1 al 12
    mostrar a que estacion del año pertenece:
        - Diciembre, enero y febrero: Invierno
        - marzo, abril, mayo: primavera
        - junio, juio y agosto: verano
        - septiembre, octubre y noviembre: Otoño
'''
mes = int(input("Introduce numero del mes (1-12): "))

match mes:
    case 12 | 1 | 2:
        print("Invierno")
    case 3 | 4 | 5:
        print("Primavera")
    case 6 | 7 | 8:
        print("Verano")
    case 9 | 10 | 11:
        print("Otoño")
    case _:
        print("Mes no valido")
    