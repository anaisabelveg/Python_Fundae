'''
    solicitar al usuario un numero del 1 al 12
    calcular cuantas horas tiene ese mes
'''
mes = int(input("Introduce el mes (1-12): "))

match mes:
    case 1 | 3 | 5 | 7 | 8 | 10 | 12:
        print(f"Nº de horas {31 * 24}")
    case 4 | 6 | 9 | 11:
        print(f"Nº de horas {30 * 24}")
    case 2:
        anyo = int(input("Dime que año para ver si es bisiesto: "))
        if anyo % 400 == 0:
            print(f"Nº de horas {29 * 24}")
        elif anyo % 4 == 0 and anyo % 100 != 0:
            print(f"Nº de horas {29 * 24}")
        else:
            print(f"Nº de horas {28 * 24}")
    case _:
        print("No es un mes valido")