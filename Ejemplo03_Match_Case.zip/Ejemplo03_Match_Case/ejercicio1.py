'''
    solicitar una letra al usuario (l,m,x,j,v,s,d)
    decir a que dia de la semana corresponde
    o si no es un dia valido 
'''
letra = input("Introduce una letra (l,m,x,j,v,s,d): ")

match letra:
    case 'l' | 'L':
        print("Es lunes")
    case 'm' | 'M':
        print("Es martes")
    case 'x' | 'X':
        print("Es miercoles")
    case 'j' | 'J':
        print("Es jueves")   
    case 'v' | 'V':
        print("Es viernes")
    case 's' | 'S':
        print("Es sabado")
    case 'd' | 'D' :
        print("Es domingo")
    case _:
        print("No es un dia valido")  