'''
    Calculadora mejorada.
    Solicitar 2 numeros reales
    soliciar que operacion: +,-,*,/
    Mostrar el resultado
'''
num1 = float(input("Introduce el primer numero: "))
num2 = float(input("Introduce el segundo numero: "))
operacion = input("Introduce la operacion (+,-,*,/): ")

'''
    match expresion:
        case valo1:
            codigo
        case valor2:
            codigo
        case _:
            codigo
'''

match operacion:
    case '+':
        print(f"{num1} + {num2} = {num1 + num2}")
    case '-':
        print(f"{num1} - {num2} = {num1 - num2}")
    case '*':
        print(f"{num1} x {num2} = {num1 * num2}")
    case '/':
        if num2 == 0:
            print("No se puede dividir entre 0")
        else:
            print(f"{num1} / {num2} = {num1 / num2}")
    case _:
        print("Operacion no valida")

