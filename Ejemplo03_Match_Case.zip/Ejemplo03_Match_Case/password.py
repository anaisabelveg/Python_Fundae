'''
    Solicitar un password al usuario
        menos de 6 caracteres: demasiado corta
        entre 6 y 8 caracteres: debil
        entre 9 y 12 caracteres: aceptable
        mas de 12 caracteres: muy buena
'''
password = input("Introduce una contraseña: ")
longitud = len(password)

match longitud:
    case num if num < 6:
        print("demasiado corta")
    case num if 6 <= num <= 8:
        print("debil")
    case num if 9 <= num <= 12:
        print("aceptable")
    case num if num > 12:
        print("muy buena")

        
numero = 9
if numero % 3 == 0:
    divisor3 = numero
else:
    divisor3 = 0

divisor3 = numero if numero % 3 == 0 else 0