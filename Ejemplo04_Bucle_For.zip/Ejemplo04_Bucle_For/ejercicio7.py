'''
    de la lista de datos, mostrar solo las vocales
'''
datos = ['t', 'a', 'w', 'p', 'o', 'z', 'i']

# opcion 1
for idx in range(len(datos)):
    if datos[idx] in ['a', 'e','i','o','u']:
        print(datos[idx], end=" ")
print()
        
# opcion 2
for idx in range(len(datos)):
    match datos[idx]:
        case 'a' | 'e' |'i'|'o'|'u':
            print(datos[idx], end=" ")
print()
        
# opcion 3
for idx in range(len(datos)):
    if (datos[idx] == 'a' or datos[idx] == 'e' or datos[idx] == 'i' or datos[idx] == 'o' or datos[idx] == 'u'):
        print(datos[idx], end=" ") 
print() 
        
  
        