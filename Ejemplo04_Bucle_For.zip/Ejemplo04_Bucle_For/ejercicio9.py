'''
    Mostrar los 100 primeros terminos de la serie de Fibonacci
    OJO!!! no hasta el numero 100
'''
