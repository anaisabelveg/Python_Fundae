'''
    solicitar al usuario un numero del 1 al 10
    mostrar la tabla de multiplicar de ese numero
    5
    5 x 1 = 5
    5 x 2 = 10
    5 x 3 = 15
    5 x 4 = 20
    ....
    5 x 10 = 50
'''
tabla = int(input("Introduce el numero de la tabla (1-10): "))

for numero in range(1, 11):
    print(f"{tabla} x {numero} = {tabla * numero}")