'''
    solicitar un numero al usuario y mostrar su factorial
    5
    5 x 4 x 3 x 2 x 1
'''
numero = int(input("Introduce un numero: "))
resultado = 1
for n in range(numero, 0, -1):
    resultado *= n
    
print(f"Factorial del numero {numero}: {resultado}")