'''
    de la lista de datos, mostrar solo las vocales que estan en un indice impar
'''
datos = ['t', 'a', 'w', 'p', 'o', 'z', 'i']

# opcion 1
for idx in range(len(datos)):
    if idx % 2 != 0 and datos[idx] in ['a', 'e','i','o','u']:
        print(datos[idx])
        
# opcion 2
for idx in range(len(datos)):
    if idx % 2 != 0:
        match datos[idx]:
            case 'a' | 'e' |'i'|'o'|'u':
                print(datos[idx])
        
# opcion 3
for idx in range(len(datos)):
    if idx % 2 != 0 and (datos[idx] == 'a' or datos[idx] == 'e' or datos[idx] == 'i' or datos[idx] == 'o' or datos[idx] == 'u'):
        print(datos[idx])  
        
# opcion 4
for idx in range(len(datos)):
    if idx % 2 != 0:
        if (datos[idx] == 'a' or datos[idx] == 'e' or datos[idx] == 'i' or datos[idx] == 'o' or datos[idx] == 'u'):
            print(datos[idx])     
        