# range es un generador de numeros
# range(inicio, final, salto)  el numero final no esta incluido

# Mostrar los numeros del 0 al 9
for numero in range(10):  # rango va de 0 hasta numero-1
    print(numero, end=" ")
print() # salto de linea

# Mostrar los numeros del 1 al 10
for numero in range(1, 11): 
    print(numero, end=" ")
print() 

# Mostrar los numeros del 0 al 10 de 2 en 2
for numero in range(0, 11, 2): 
    print(numero, end=" ")
print() 

# Mostrar los numeros del 10 al 1 en modo decreciente
for numero in range(10, 0, -1): 
    print(numero, end=" ")
print() 

# Mostrar los numeros del 10 al 0 en modo decreciente de 2 en 2
for numero in range(10, -1, -2): 
    print(numero, end=" ")
print() 