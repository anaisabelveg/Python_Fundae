'''
    solicitar al usuario un numero entero
    mostrar si es primo o no
    un numero es primo si solo es divisible por si mismo y la unidad
    crear un bucle para buscar sus posibles divisores: 2 hasta numero-1
'''
# break
numero = int(input("Introduce un numero: "))

# Todo numero es primo salvo que se demuestre lo contrario
esPrimo = True
for divisor in range(2, numero):
    print("Probando divisor", divisor)
    if numero % divisor == 0:
        esPrimo = False
        break  # Da por finalizado el bucle
        
if esPrimo:
    print(f"El numero {numero} es primo")
else:
    print(f"El numero {numero} no es primo")