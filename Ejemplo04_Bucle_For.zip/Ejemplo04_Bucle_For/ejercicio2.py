'''
    Mostrar las 10 tablas de multiplicar
    2 bucles: 
        1º es el recorre las tablas
        2º es el recorre los numeros de la tabla
'''
for tabla in range(1, 11):
    print("Tabla del numero:", tabla)
    
    for numero in range(1, 11):
        print(f"{tabla} x {numero} = {tabla * numero}")
    print()