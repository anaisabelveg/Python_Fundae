'''
    mostrar los numeros primos del 1 al 100
'''
for numero in range(1, 101):
    esPrimo = True

    for divisor in range(2, numero):
        if numero % divisor == 0:
            esPrimo = False
            break  
        
    if esPrimo:
        print(numero)
    