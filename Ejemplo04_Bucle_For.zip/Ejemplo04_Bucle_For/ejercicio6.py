nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']

# Recorremos la lista por elemento
for nombre in nombres:
    print(nombre, end = " ")
print()

# Recorrer la lista por indice
# len(nombres) es la longitud de la lista (nº elementos)
for idx in range( len(nombres) ):  # 0 al 4
    print(nombres[idx], end = " ")
print()

# Mostrar solo los nombres que estan en un indice par
for idx in range( len(nombres) ):  # 0 al 4
    if idx % 2 == 0:
        print(nombres[idx], end = " ")
print()