# cuando todos los elementos van entre [] es una lista
nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']

# mostrar todos los nombres de la lista
# elemento es una variable que acabo de invertarme y se conoce como variable auxiliar 
for elemento in nombres:
    print(elemento)
   
    
# crear una lista de numeros y mostrar la suma de todos ellos
numeros = [3,8,1,5,9]
resultado = 0    # variable donde acumulo la suma de todos los numeros
for num in numeros:
    resultado += num      # resultado = resultado + num
print("Resultado", resultado)
    