'''
    un fabrica produce 350 productos al dia
        - aumenta la produccion en 125 unidades
        - reduce la producion en 75 unidades
        - duplica la produccion
        - divide la produccion entre 5
    calcula cuantas unidades sobran al agrupar la produccion en lotes de 12 unidades
'''
produccion = 350
produccion += 125
produccion -= 75
produccion *= 2
produccion /= 5
produccion %= 12
print("Unidades sobrantes", produccion)
print(f"Unidades sobrantes {produccion}")