'''
    un alumno tiene una nota de 7.5
        - si la nota es superior a 5
        - si la nota es igual o superior a 7
        - si la nota inferior a 10
        - si la nota es exactamente 10
        - si la nota es distinta de 5
'''
nota = 7.5
print("La nota es superior a 5?", nota > 5)
print(f"la nota es igual o superior a 7 {nota >= 7} ")
print("la nota inferior a 10", nota < 10)
print("la nota es exactamente 10", nota == 10)
print("la nota es distinta de 5", nota != 5)