'''
    Comentarios de Bloque (Docstring)
    3 comillas simples o dobles
    Ejemplo de tipos de datos en Python
'''

# numeros enteros (int)
numero1 = 8
numero2 = 4
suma = numero1 + numero2
print(suma)
print(type(suma))
print("Resultado:", suma)

# numeros reales (float)
base = 4.89
altura = 9.23
triangulo = base * altura / 2
print(type(triangulo))
print("Area del triangulo:", triangulo)
# round(numero, num_decimales)
print("Area del triangulo:", round(triangulo, 2) )

# booleanos: True o False (bool)
resuelto = True
print(type(resuelto))
print("Problema resuelto?", resuelto)

# Cadenas de texto (str)
# se pueden utilizar comillas simples o dobles
nombre = "Juan"
apellido = 'Lopez'
print(nombre, apellido)
print(nombre, apellido, sep="-")
print(type(nombre))
# concatenar (unir) cadenas de texto
print("Hola, me llamo " + nombre + " " + apellido)