'''
    Una persona tiene en su cuenta 1250€
        - recibe una transferencia de 375€
        - paga 3 facturas de 85€ cada una
        - recibe un bizum de 200€
        - retira el 10% de su saldo (necesitareis otra variable)
    Mostrar el saldo final    
'''
saldo = 1250
saldo += 375
saldo -= 85 * 3   # primero se resuelve la operacion 85 * 3, luego lo resta de saldo
saldo += 200
#retira = saldo * 10 / 100
#saldo -= retira
saldo -= saldo * 10 / 100
print("Saldo final:", int(saldo)) # lo convierto a entero para quitarle los decimales
print(f"Saldo final: {int(saldo)}")