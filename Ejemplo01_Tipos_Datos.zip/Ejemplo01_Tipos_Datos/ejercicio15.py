'''
    solicitar el usuario y password por teclado
        - Mostrar si el usuario es "admin" y el password es "python123"        
'''
import getpass

usuario = input("Introduce usuario: ")
password = getpass.getpass("Introduce password: ")

print("Credenciales son validas?", usuario == "admin" and password == "python123")