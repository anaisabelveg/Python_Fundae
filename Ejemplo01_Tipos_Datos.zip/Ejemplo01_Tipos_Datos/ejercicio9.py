'''
    tenemos 47 caramelos a repartir entre 5 niños.
    Mostrar cuantos sobran
'''
caramelos = 47
caramelos %= 5
print("Sobran", caramelos, "caramelos")
print(f"Sobran {caramelos} caramelos")