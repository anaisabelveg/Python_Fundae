'''
    una piscina permite entrada a los que tienen entre 12 y 65 años
        - comprobar si tiene entre 12 y 65
        - si tiene menos de 12 o mas de 65
        - si no tiene 18 años
        - si tiene mas de 18 años y menos de 30

    condicion and condicion
    condicion or condicion
    not condicion
'''
edad = 25
print("si tiene entre 12 y 65", edad >= 12 and edad <= 65)
print("si tiene menos de 12 o mas de 65", edad < 12 or edad > 65)
print("si no tiene 18 años", not edad == 18)
print("si tiene mas de 18 años y menos de 30", edad > 18 and edad < 30)