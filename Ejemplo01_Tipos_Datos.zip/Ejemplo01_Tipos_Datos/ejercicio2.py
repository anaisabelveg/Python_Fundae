'''
    Solicitar 2 numeros enteros al usuario y mostrar el resultado de:
    suma, resta, multiplicacion, division, division entera, potencia, resto de la division
'''

'''
    Tipos de nomenclatura:
        camelCase (Java) UnirPalabrasConPrimeraLetraMayuscula
        snake_case (Python) unir_palabras_como_si_fuese_una_serpiente
        kebab-case (CSS)   une-las-palabras-como-si-fuese-una-brocheta
'''

num1 = int(input("Introduce un numero: "))
num2 = int(input("Introduce otro numero: "))

suma = num1 + num2
print("Suma:", suma)
print("Resta:", num1 - num2)
print("Multiplicacion:", num1 * num2)
print("Division:", num1 / num2)
print("Division entera:", num1 // num2)
print("Potencia:", num1 ** num2)
print("Modulo o resto de la division", num1 % num2)