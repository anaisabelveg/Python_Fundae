'''
    crear una variable puntos = 100.
    un jugador comienza la partida con 100 puntos, gana 25, pierde 15 y despues 
    duplica su puntuacion.
    Mostrar sus puntos finales
'''
puntos = 100
puntos += 25
puntos -= 15
puntos *= 2
print("Cuantos puntos tiene?", puntos)
print(f"Cuantos puntos tiene? {puntos}")