'''
    Salgo a cenar con mis amigos y tenemos que repartir la cuenta
    Datos necesito: cuenta, personas, propina
    Mostrar cuanto tenemos que pagar cada uno
'''

cuenta = float(input("Importe de la cuenta: "))
personas = int(input("Cuantas personas somos?: "))
propina = float(input("Que propina dejamos?: "))

total_gasto = cuenta + propina

pago_persona = total_gasto / personas

print(f"Cuenta: {cuenta}")
print(f"Propina: {propina}")
print(f"Total: {total_gasto}")
print(f"Somos {personas} personas")
print(f"Tocamos a {pago_persona:.2f}€")