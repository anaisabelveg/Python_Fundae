# Siempre que se introduce un dato por teclado,
# el interprete de Python lo considera un str

# convertir un str a numero entero int(str)
numero1 = int(input("Introduce un numero:"))
print(type(numero1))
numero2 = int(input("Introduce otro numero:"))
print(type(numero2))
suma = numero1 + numero2



# convertir un str a numero real  float(str)
lado = input("Introduce el lado del cuadrado:") # la parte decimal con .
area_cuadrado = float(lado) * float(lado)
print("Area del cuadrado:", area_cuadrado)
area_cuadrado = float(lado) ** 2   # potencia: base ** exponente
print("Area del cuadrado:", area_cuadrado)


# convertir un int a str.  str(int)
# print("Suma:" + suma) # TypeError: can only concatenate str (not "int") to str
print("Suma: " + str(suma))

# convertir un booleano a numerico
# False = 0,  True = 1
print(8 + False) # 8
print(8 + True)  # 9
print(True + False) # 1

# Todo tipo de dato es convertible a str
print(str(True))
print(str(4.67))