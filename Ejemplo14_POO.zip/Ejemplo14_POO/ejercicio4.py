'''
    crear una clase Figura con las coordenas x,y y un metodo calcular_area (raise Exception)
    
    crear la clase Circulo, sobrescribir el metodo calcular_area
    crear la clase Rectangulo, sobrescribir el metodo calcular_area
'''
