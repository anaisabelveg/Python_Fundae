class Fecha:
    def __init__(self, dia, mes, anyo):
        # propiedades publicas: se puede acceder a ellas para leer o modificar su valor
        self.dia = dia
        self.mes = mes
        self.anyo = anyo
        
    def mostrar_fecha(self):
        return f"{self.dia}/{self.mes}/{self.anyo}"
    
hoy = Fecha(2645,-110,20267765)
hoy.dia = 5432
print(hoy.mostrar_fecha())

'''
    Una clase encapsulada tiene todas sus propiedades como privadas y se accede a ellas 
    a través de los métodos de acceso publico: getter y setter
'''
class FechaEncapsulada:
    def __init__(self, dia, mes, anyo):
        # propiedades privadas: solo se puede acceder a ellas desde dentro de la clase
        # En python para declarar un recurso privado __nombre
        self.__dia = 0
        self.__mes = 0
        self.__anyo = 0
        self.setDia(dia)
        self.setMes(mes)
        self.setAnyo(anyo)
        
    def getDia(self):  # metodos de lectura, retornan el valor de una variable
        return self.__dia
    
    def setDia(self, dia):  # metodo de escritura, asigna el valor recibido a la variable
        if dia >= 1 and dia <= 31:
            self.__dia = dia
        else:
            print("Dia no valido")
            
    def getMes(self):
        return self.__mes
    
    def setMes(self, mes):
        if mes >= 1 and mes <= 12:
            self.__mes = mes
        else:
            print("Mes no valido")
            
    def getAnyo(self):
        return self.__anyo
    
    def setAnyo(self, anyo):
        if anyo == 2026 or anyo == 2027:
            self.__anyo = anyo
        else:
            print("Año no valido")
        
    def mostrar_fecha(self):
        return f"{self.__dia}/{self.__mes}/{self.__anyo}"
    
hoy = FechaEncapsulada(2645,-110,20267765)
#hoy.dia = 5432
hoy.setDia(26)
print(hoy.__mes) # No tienes acceso a una propiedad privada
print(hoy.mostrar_fecha())