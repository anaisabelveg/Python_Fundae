'''
    Crear clase encapsulada Empleado con 3 propiedades:
        nombre
        sueldo (debe ser mayor o igual al 35000)
        antiguedad (como mucho 2026)
        
    crear un objeto Empleado
    cambiar el sueldo a 27000
    cambiar la antiguedad a 2028
    mostrar la informacion
'''
class Empleado:
    
    def __init__(self, nombre, sueldo, antiguedad):
        self.__nombre = ''
        self.__sueldo = 0
        self.__antiguedad = 0
        self.setNombre(nombre)
        self.setSueldo(sueldo)
        self.setAntiguedad(antiguedad)
        
    def getNombre(self):
        return self.__nombre
    
    def setNombre(self, nombre):
        self.__nombre = nombre
    
    def getSueldo(self):
        return self.__sueldo
    
    def setSueldo(self, sueldo):
        if sueldo >= 35000:
            self.__sueldo = sueldo
        else:
            print("El sueldo debe ser igual o superior a 35000")
        
    def getAntiguedad(self):
        return self.__antiguedad
    
    def setAntiguedad(self, antiguedad):
        if antiguedad <= 2026:
            self.__antiguedad = antiguedad
        else:
            print("La antiguedad no puede ser superior a 2026")
            
    def mostrarInfo(self):
        return f"Nombre: {self.__nombre}, Sueldo {self.__sueldo}, Antiguedad: {self.__antiguedad}"

   
# crear un objeto Empleado
empleado = Empleado("Pepito", 38000, 2024)  

# cambiar el sueldo a 27000
empleado.setSueldo(27000)
    
# cambiar la antiguedad a 2028
empleado.setAntiguedad(2028)
    
# mostrar la informacion
print(empleado.mostrarInfo())
