'''
    Crear la clase calculadora con 4 metodos: sumar, restar, multiplicar y dividir
    Solicitar 2 numeros al usuario
    llamar a los 4 metodos (pasando los numeros) y mostrar el resultado
'''
class Calculadora:
    
    # Si no pongo el contructor, coge el contructor por defecto
    '''
        def __init__(self):
            pass
    '''  
    def sumar(self, n1, n2):
        return n1 + n2
    
    def restar(self, n1, n2):
        return n1 - n2
        
    def multiplicar(self, n1, n2):
        return n1 * n2
        
    def dividir(self, n1, n2):
        return n1 / n2

try:
    numero1 = int(input("Introduce numero1: "))
    numero2 = int(input("Introduce numero1: "))
    
    calc = Calculadora()
    print(f"{numero1} + {numero2} = {calc.sumar(numero1, numero2)}")
    print(f"{numero1} - {numero2} = {calc.restar(numero1, numero2)}")
    print(f"{numero1} * {numero2} = {calc.multiplicar(numero1, numero2)}")
    print(f"{numero1} / {numero2} = {calc.dividir(numero1, numero2)}")
except ValueError as error:
    print("Debe ser numerico", error)
except ZeroDivisionError:
    print("No se puede dividir por 0")