class Persona:
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad
    
    def mostrar_info(self):
        return f"Nombre: {self.nombre}, Edad: {self.edad}"
    

class Empleado(Persona):
    # Heredamos los recursos publicos de Persona
    def __init__(self, nombre, edad, sueldo):
        # llama al constructor de la superclase y le pasamos el nombre y la edad
        super().__init__(nombre, edad)
        self.sueldo = sueldo
        
    def mostrar_info(self):
        # super().mostrar_info() llamar al mostrar_info de la superclase
        return f"{super().mostrar_info()}, Sueldo:{self.sueldo}"    
        
        
empleado = Empleado("Juan", 28, 37000)
print(empleado.mostrar_info())