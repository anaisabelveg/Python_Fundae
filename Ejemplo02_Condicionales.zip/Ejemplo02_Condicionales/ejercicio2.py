'''
    solicitar el usuario y password por teclado
        - si el usuario es "admin" y el password es "python123"     
        - Mostrar "credenciales no validas" o "credenciales correctas"
'''
usuario = input("Introduce usuario: ")
password = input("Introduce password: ")

if usuario == "admin" and password == "python123":
    print("credenciales correctas")
else:
    print("credenciales no validas")