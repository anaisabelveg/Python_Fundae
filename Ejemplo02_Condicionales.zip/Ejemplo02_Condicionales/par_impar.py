'''
    mostrar si un numero es par
'''
numero = 43

if numero % 2 == 0:
    print("Es par")
else:
    print("Es impar") 
    
    
'''
    mostrar si es par y multiplo de 3
'''
if numero % 2 == 0 and numero % 3 == 0:
    print("Es par y multiplo de 3")
elif numero % 2 != 0 and numero % 3 != 0:
    print("Es impar pero no multiplo de 3")
elif numero % 2 != 0 and numero % 3 == 0:
    print("Es impar y es multiplo de 3")
else:
    print("Es par pero no multiplo de 3")