'''
    Solicitar una nota de 0 a 10 (numero real)
        - si no esta entre 0 y 10 la nota no es valida
        - si es menor de 5 es suspenso
        - de 5 a 6 aprobado
        - de 6 a 7 bien
        - de 7 a 8.5 notable
        - mas de 8.5 sobresaliente
'''
nota = float(input("Introduce tu nota 0-10: "))

if nota < 0 or nota > 10:
    print("Esa nota no es valida")
elif nota < 5:
    print("Suspenso")
elif nota < 6:
    print("Aprobado")
elif nota < 7:
    print("Bien")
elif nota < 8.5:
    print("Notable")
else:
    print("Sobresaliente")