'''
    una piscina permite entrada a los que tienen entre 12 y 65 años
        - solicitar la edad por teclado
        - acceso permitido si esta en el rango de edad
        - lo siento, eres menor de 12 años
        - lo siento, eres mayor de 65 años  
'''
edad = int(input("Introduce tu edad: "))

if edad >= 12 and edad <= 65:
    print("Acceso permitido")
elif edad < 12:
    print("Lo siento, eres menor de 12 años")
else:
    print("Lo siento, pero eres mayor de 65 años")